# ODE Estimation

Modify the parameters, model, etc in **generate.py** and run it :)  
